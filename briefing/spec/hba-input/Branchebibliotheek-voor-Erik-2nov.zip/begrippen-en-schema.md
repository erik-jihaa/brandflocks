# Begrippen en schema: branchebibliotheek markthygiëne

Rogier Heijning, Hero Brands, 18 oktober 2026 (versie 1.2). Hoort bij de projectinstructie. Het schema is bindend.

## Begrippen

- **Hygiënefactor:** een belofte of eigenschap die in de branche de toegangsprijs is. Ontbreekt hij, dan doe je niet mee. Heb je hem, dan onderscheid je je niet. Voorbeeld koffiebranderij: "vers gebrand", "duurzaam", "branddatum op de verpakking".
- **Categorietaal:** de woorden en frasen waarmee de branche over zichzelf praat. Voorbeeld accountancy: "ontzorgen", "korte lijnen", "persoonlijk en deskundig".
- **Strawman:** een tegenstelling die niemand claimt, en die bedrijven gebruiken om anders te lijken ("geen beunhazen", "geen standaardoplossingen", "geen loze beloftes"). Omdat iedereen hem gebruikt, is ook de strawman hygiëne.
- **Verplichte taal:** wat je moet zeggen of tonen (waarschuwingen, registraties, keurmerken, disclaimers).
- **Verboden of beperkte claims:** wat je niet of alleen onder voorwaarden mag zeggen, met de regel waar het uit volgt.
- **Veilige uitwijkformules:** de formuleringen waar de branche naar uitwijkt omdat de directe claim niet mag of niet durft. Dit is de schakel tussen vorm 2 en de hygiëne.
- **Ongeschreven taboes:** wat de branche uit gewoonte niet zegt (prijs, concurrenten, eigen fouten).
- **Soort belofte:** `identiteit` (wat het merk zegt te zijn of te doen) of `service` (verzending, abonnement, openingstijden, betaalgemak). Servicebeloftes zijn vaak hygiëne, maar wegen bij drift minder zwaar.
- **Brancheconventie:** een vaste manier van werken of prijzen in de branche (bijvoorbeeld pakketprijzen in de uitvaartzorg). Een merk dat breekt met een conventie, kan zich daardoor onderscheiden.
- **Differentiatie-as:** een dimensie waarop merken in deze branche zich wél werkelijk van elkaar onderscheiden.
- **Markt-archetype:** het archetype dat de branche als geheel uitstraalt (bijvoorbeeld de Verzorger in de zorg, de Maker bij ambachtelijke bedrijven). Kies uit de twaalf klassieke archetypen. Een merk met hetzelfde archetype als zijn branche moet zijn onderscheid harder bewijzen.

**Onderscheid, hygiëne of strawman?** Het verschil moet je zien:

- "Lange klantrelaties" in de loyaliteitsbranche is hygiëne: het is de definitie van de branche.
- "Geen snelle verkoop" is een strawman: niemand in die branche claimt snelle verkoop.
- "Alleen werken voor merken die hun kortingsacties afbouwen" is mogelijk onderscheid: het is een keuze die opdrachten kost en die je nergens anders vindt.
- Een keuze kan onderscheidend zijn ten opzichte van de hele markt, maar hygiëne binnen de branche. Desem en lange rijstijd onderscheiden een bakker van de supermarkt, niet van andere ambachtelijke bakkers. **De vergelijkingsgroep is altijd de branche, niet de hele markt.**

## Schema per branche

```json
{
  "branche_id": "koffiebranderij",
  "branche_naam": "Koffiebranderij / specialty coffee, consument",
  "afbakening": "Branderijen met eigen merk die aan consumenten verkopen via winkel of webshop. Niet: koffieketens, supermarktmerken.",
  "markt": "B2C",
  "peildatum": "2026-10",
  "bronnen_kwaliteit": {"oordeel": "middel", "reden": "..."},
  "onderzochte_bedrijven": [{"naam": "...", "url": "..."}],
  "steekproef": {"groot": 3, "middelgroot": 4, "klein": 5, "premium": 4, "middensegment": 4, "gewoon_mkb": 4},
  "markt_archetype": {"archetype": "Maker", "toelichting": "...", "bron": "inschatting"},
  "werk_en_producttaal": {"termen": ["..."], "telt_als_hygiene": false},
  "publieken": [{"publiek_id": "klanten", "naam": "...", "onderzocht": true}],
  "hygienefactoren": [
    {"factor_id": "K-H1", "familie_id": "K-F1", "soort": "identiteit", "item": "vers gebrand", "status": "hygiene", "frequentie": "9 van 12", "bedrijven": ["koffie_01"], "semantische_varianten": ["..."], "voorbeelden": [{"tekst": "...", "url": "..."}], "bron": "websites"}
  ],
  "categorietaal": [
    {"item": "passie voor kwaliteit", "status": "hygiene", "publiek_id": "klanten", "frequentie": "7 van 12", "bedrijven": ["koffie_02"], "voorbeelden": [{"tekst": "...", "url": "..."}]}
  ],
  "strawmen": [
    {"item": "geen supermarktkoffie", "status": "minderheid", "frequentie": "...", "voorbeelden": [], "toelichting": "..."}
  ],
  "verplichte_taal": [
    {"item": "...", "regel": "...", "bron": "...", "zeker": true}
  ],
  "verboden_of_beperkte_claims": [
    {"claim": "...", "regel": "...", "bron": "...", "zeker": true}
  ],
  "veilige_uitwijkformules": [
    {"formule": "...", "uitwijk_voor": "...", "regel": "...", "status": "patroon", "frequentie": "...", "voorbeelden": []}
  ],
  "ongeschreven_taboes": [{"item": "...", "toelichting": "..."}],
  "brancheconventies": [{"conventie": "...", "wat_breken_kost": "..."}],
  "differentiatie_assen": [{"as": "...", "toelichting": "...", "voorbeeld": {"bedrijf": "...", "url": "..."}}],
  "lopende_debatten": [{"debat": "...", "bron": "..."}],
  "onzekerheden": ["..."]
}
```

